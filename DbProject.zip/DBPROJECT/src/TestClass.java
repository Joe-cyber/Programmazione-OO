import java.io.Serializable;

public class TestClass implements Serializable{

	private static final long serialVersionUID = 1L;
	private String aString;
	private int anInt;
	public TestClass()
	{
		aString="Una stringa";
		anInt=1;
	}

	public String toString() 
	{
		return getClass().getName()+"[aString="+aString+", anInt="+anInt+"]";
	}
}
