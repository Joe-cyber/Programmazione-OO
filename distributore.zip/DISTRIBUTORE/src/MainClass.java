public class MainClass {
	public static void main(String[] args)
	{
		Distributore distr=new Distributore(5);
		while(distr.getNumeroLattine()>0)
		{
			System.out.println("Ci sono "+distr.getNumeroLattine()+" lattine e "+distr.getNumeroGettoni()+" gettoni");
			distr.compraLattina();
		}
		distr.compraLattina();
		distr.aggiungiLattine(3);
		System.out.println("Ci sono "+distr.getNumeroLattine()+" lattine e "+distr.getNumeroGettoni()+" gettoni");
	}
}