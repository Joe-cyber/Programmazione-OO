
public class DataSet{
	private double sum;
	private int count;
	private Measurable minimum;
	private Measurable maximum;
	public DataSet()
	{
		sum=0;
		count=0;
		minimum=null;
		maximum=null;
	}
	public void addMeasurable(Measurable x)
	{
		sum+=x.getMeasure();
		if(count==0 || minimum.getMeasure()>x.getMeasure())
			minimum=x;
		if(count==0 || maximum.getMeasure()<x.getMeasure())
			maximum=x;
		count++;
	}
	public double getSum()
	{
		return sum;
	}
	public int getCount()
	{
		return count;
	}
	public Measurable getMax()
	{
		return maximum;
	}
	public Measurable getMin()
	{
		return minimum;
	}
}
