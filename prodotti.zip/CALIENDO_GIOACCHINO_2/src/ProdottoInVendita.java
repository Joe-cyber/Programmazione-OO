
public class ProdottoInVendita extends Prodotto{
	private long numeroConfezioni;
	private Tag tag;
	public ProdottoInVendita(long codice,String descrizione,long numeroConfezioni,Tag tag)
	{
		super(codice,descrizione);
		this.tag=tag;
		this.numeroConfezioni=numeroConfezioni;
	}
	//modificatore
	public void setNumeroConfezioni(long numeroConfezioni)
	{
		this.numeroConfezioni=numeroConfezioni;
	}
	public void setTag(Tag tag)
	{
		this.tag=tag;
	}
	//accesso
	public Tag getTag()
	{
		return tag;
	}
	public long getNumeroConfezioni()
	{
		return numeroConfezioni;
	}
	public String toString()
	{
		return getClass().getName()+" "+super.toString()+" [numeroConfezioni="+numeroConfezioni+", tag="+tag+"]";
	}
	public boolean equals(Object anObject)
	{
		if(!super.equals(anObject))
			return false;
		ProdottoInVendita temp=(ProdottoInVendita) anObject;
		return temp.tag.equals(tag)&&temp.numeroConfezioni==numeroConfezioni;
	}
	public ProdottoInVendita clone()
	{
		ProdottoInVendita cloned=(ProdottoInVendita) super.clone();
		if(cloned==null)
			return null;
		cloned.tag=tag;
		cloned.numeroConfezioni=numeroConfezioni;
		return cloned;
	}
}
