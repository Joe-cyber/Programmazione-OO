
public class CentroUrbano implements Cloneable{
	private String nome;
	private Nazione nazione;
	private long numeroAbitanti;
	private double temperatura;
	//costruttore
	public CentroUrbano(String nome,Nazione nazione,long numeroAbitanti,double temperatura)
	{
		this.nome=nome;
		this.nazione=nazione.clone();
		this.numeroAbitanti=numeroAbitanti;
		this.temperatura=temperatura;
	}
	//metodi modificatori
	public String getNome()
	{
		return nome;
	}
	public Nazione getNazione()
	{
		return nazione.clone();
	}
	public long getNumeroAbitanti()
	{
		return numeroAbitanti;
	}
	public double getTemperatura()
	{
		return temperatura;
	}
	//metodi accesso
	public void setNome(String nome)
	{
		this.nome=nome;
	}
	public void setNazione(Nazione nazione)
	{
		this.nazione=nazione.clone();
	}
	public void setNumeroAbitanti(long numeroAbitanti)
	{
		this.numeroAbitanti=numeroAbitanti;
	}
	public void setTemperatura(double temperatura)
	{
		this.temperatura=temperatura;
	}
	public String toString()
	{
		return getClass().getName()+"[nome="+nome+", nazione="+nazione+", numeroAbitanti="+numeroAbitanti+", temperatura="+temperatura+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass())
			return false;
		CentroUrbano temp=(CentroUrbano) anObject;
		Double temperatura1=temp.temperatura,temperatura2=temperatura;
		return temp.nome.equals(nome)&&temp.nazione.equals(nazione)&&temp.numeroAbitanti==numeroAbitanti&&temperatura1.equals(temperatura2);
	}
	public CentroUrbano clone()
	{
		try
		{
			return (CentroUrbano)super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
