
public class MainClass {
	public static void main(String[] args)
	{
		WriteInFile<TestClass> wf=new WriteInFile<TestClass>(new TestClass());
		wf.closeFile();
		WriteFileInDB<TestClass> wfdb= new WriteFileInDB<TestClass>(new TestClass());
		wfdb.loadTableDB();
		wfdb.closeFile();
	}
}
