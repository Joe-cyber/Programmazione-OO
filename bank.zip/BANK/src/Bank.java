import java.util.ArrayList;

public class Bank {
	ArrayList<BankAccount> accounts;
	public Bank()
	{
		accounts=new ArrayList<BankAccount>();
	}
	public void addAccount(BankAccount a) 
	{
		accounts.add(a.clone());
	}
	public float getTotalBalance()
	{
		float total=0.0f;
		for(int i=0;i<accounts.size();i++)
			total+=(accounts.get(i)).getSaldo();
		return total;
	}
	public int count(float atLeast)
	{
		int count=0;
		for(int i=0;i<accounts.size();i++)
			if(((accounts.get(i)).getSaldo())>=atLeast)
				count++;
		return count;
	}
	public BankAccount find(int accountNumber)
	{
		for(int i=0;i<accounts.size();i++)
			if(((accounts.get(i)).getNumConto())==accountNumber)
				return (accounts.get(i)).clone();
		return null;
	}
	public BankAccount getMaximum()
	{
		if(accounts.size()==0)
			return null;
		BankAccount maximum=accounts.get(0);
		for(int i=1;i<accounts.size();i++)
			if(maximum.getSaldo()<accounts.get(i).getSaldo())
				maximum=accounts.get(i);
		return maximum;
	}
	public void addAccount(float initialBalance,Cliente customerName)
	{
		int num=accounts.size()+1;
		while(find(num)!=null)
			num++;
		BankAccount a=new BankAccount(initialBalance,customerName,num);
		addAccount(a);
	}
	public void deposit(int accountNumber, float amount)
	{
		find(accountNumber).versamento(amount);
	}
	public boolean withdraw(int accountNumber,float amount) 
	{
		return (find(accountNumber).prelievo(amount));
	}
	public float getBalance(int accountNumber) 
	{
		return (find(accountNumber).getSaldo());
	}
	public int transfer(int fromAccNumber,int toAccNumber,float amount)
	{
		if(find(fromAccNumber).prelievo(amount))
		{
			find(toAccNumber).versamento(amount);
			return 1;
		}
		return 0;
	}
}
