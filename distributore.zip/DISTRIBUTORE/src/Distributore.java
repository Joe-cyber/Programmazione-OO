public class Distributore {
	private int gettoni;
	private int lattine;
	public Distributore()
	{
		gettoni=lattine=0;
	}
	public Distributore(int numeroLattine)
	{
		lattine=numeroLattine;
		gettoni=0;
	}
	public void aggiungiLattine(int numeroLattine)
	{
		lattine+=numeroLattine;
	}
	public void compraLattina()
	{
		if(lattine>0)
		{
			lattine--;
			gettoni++;
			System.out.println("Lattina comprata");
		}
		else
			System.err.println("Distributore vuoto");
	}
	public int getNumeroLattine()
	{
		return lattine;
	}
	public int getNumeroGettoni()
	{
		return gettoni;
	}
}
