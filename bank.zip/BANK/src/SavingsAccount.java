
public class SavingsAccount extends BankAccount
{
	private float interestRate;
	public SavingsAccount(float rate,Cliente nomeIntestatario,int numeroConto)
	{
		super(nomeIntestatario, numeroConto);
		interestRate=rate;
	}
	public SavingsAccount(float rate,Cliente nomeIntestatario,int numeroConto,float saldo)
	{
		super(saldo,nomeIntestatario, numeroConto);
		interestRate=rate;
	}
	public float getInterestRate()
	{
		return interestRate;
	}
	public void addInterest()
	{
		versamento(getSaldo()*interestRate/100);
	}
	public String toString()
	{
		return getClass().getName()+" "+super.toString()+" [interestRate="+interestRate;
	}
	public boolean equals(Object anObject)
	{
		if(!super.equals(anObject))
			return false;
		SavingsAccount temp=(SavingsAccount) anObject;
		Float f1=temp.interestRate,f2=interestRate;
		return f1.equals(f2);
	}
	public SavingsAccount clone()
	{
			SavingsAccount cloned=(SavingsAccount) super.clone();
			if(cloned!=null)
			{
				cloned.interestRate=interestRate;
				return cloned;
			}
			return null;
	}
}
