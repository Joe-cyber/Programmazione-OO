import java.io.Serializable;

public interface InseribleInDb extends Serializable{
	String insertCommandSQL();
}
