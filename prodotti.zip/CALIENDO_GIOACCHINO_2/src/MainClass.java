
public class MainClass {
	public static void main(String[] args)
	{
		Cliente cliente1=new Cliente("Gioacchino","Via dentice,61","3462346671"),cliente2=new Cliente("Francesca","boh, fisciano");
		ElencoClienti clienti=new ElencoClienti(cliente1);
		
		clienti.addCliente(cliente2);
		System.out.println(clienti.getElencoClienti());
		cliente2.setIndirizzo("Sei scema");
		clienti.addCliente(cliente2);
		System.out.println(clienti.getElencoClienti());
		System.out.println(clienti.removeCliente(cliente1));
		System.out.println(clienti.getElencoClienti());
	}
}
