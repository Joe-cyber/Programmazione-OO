public class Targa {
	private String c1;
	private String c2;
	private String c3;
	public Targa(String c1,String c2,String c3)
	{
		if((c1.length()==2) && (c3.length()==2) && (onlyNumberInString(c1)) && (onlyNumberInString(c3)) && (c2.length()==3) && (noCharactersInString(c2.toUpperCase())))
		{
			this.c1=c1.toUpperCase();
			this.c3=c3.toUpperCase();
			this.c2=c2;
		}
		else
			System.err.println("Targa non valida");
	}
	private boolean onlyNumberInString(String s)
	{
		int n=0;
		while((n<=9)&&(!s.contains(Integer.toString(n))))
			n++;
		if(n<=9)
			return false;
		return true;
	}
	private boolean noCharactersInString(String s)
	{
		char c='A';
		while((c<='Z')&&(!s.contains(Character.toString(c))))
			c++;
		if(c<='Z')
			return false;
		return true;
	}
	public String getC1()
	{
		return c1;
	}
	public String getC2()
	{
		return c2;
	}
	public String getC3()
	{
		return c3;
	}
}
