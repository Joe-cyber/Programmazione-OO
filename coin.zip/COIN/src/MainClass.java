
public class MainClass {
	public static void main(String[] args)
	{
		Coin quarter=new Coin(0.25,"Quarter");
		Coin dime=new Coin(0.1,"Dime");
		Coin nickel=new Coin(0.05,"Nickel");
		Purse p=new Purse();
		p.addCoin(nickel);
		p.addCoin(dime);
		p.addCoin(quarter);
		Coin min=p.getMin();
		System.out.println("Il minimo � "+min.getValore());
		Coin max=p.getMax();
		System.out.println("Il massimo � "+max.getValore());
		System.out.println("Ci sono "+p.conteggio()+" monete");
		System.out.println("Dal valore di "+p.getTotal());
		p.removeCoin(min);
		System.out.println("Ci sono "+p.conteggio()+" monete");
		System.out.println("Il quarter si trova all'indice "+p.find(quarter));
	}
}
