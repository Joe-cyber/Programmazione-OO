
public class Nazione implements Cloneable{
	private String nome;
	private long numeroAbitanti;
	//costruttore
	public Nazione(String nome,long numeroAbitanti)
	{
		this.nome=nome;
		this.numeroAbitanti=numeroAbitanti;
	}
	//metodi modificatori
	public void setNome(String nome)
	{
		this.nome=nome;
	}
	public void setNumeroAbitanti(long numeroAbitanti)
	{
		this.numeroAbitanti=numeroAbitanti;
	}
	//metodi accesso
	public String getNome()
	{
		return nome;
	}
	public long getNumeroAbitanti()
	{
		return numeroAbitanti;
	}
	public String toString()
	{
		return getClass().getName()+"[nome="+nome+", numeroAbitanti="+numeroAbitanti+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass())
			return false;
		Nazione temp=(Nazione) anObject;
		return temp.nome.equals(nome)&&temp.numeroAbitanti==numeroAbitanti;
	}
	public Nazione clone()
	{
		try
		{
			return (Nazione)super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
