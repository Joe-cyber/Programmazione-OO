import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class WriteInFile <E extends Serializable>{

	private String fileName;
	private int written;
	private ObjectOutputStream fOut;
	
	//Constructors
	public WriteInFile(E item)
	{
		written=0;
		fileName=item.getClass().getName()+".dat";
		openFile();
		writeObject(item);
	}
	//metode who write the strut in the file
	public void writeObject(E item)
	{
		try 
		{
			fOut.writeObject(item);
			System.out.println("Ho scritto");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	//metode who open file
	public void openFile()
	{
		try 
		{
			fOut=new ObjectOutputStream(new FileOutputStream(new File(fileName),true));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	//metode who close the file
	public void closeFile()
	{
		try 
		{
			fOut.close();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	//access metode
	public String getFileName()
	{
		return fileName;
	}
	public int getWritten()
	{
		return written;
	}
}
