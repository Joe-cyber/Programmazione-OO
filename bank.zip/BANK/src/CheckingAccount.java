
public class CheckingAccount extends BankAccount
{
	private int transactionCount;
	public final int FREE_TRANSACTIONS=5;
	public final float TRANSACTION_FEE=2.00f;
	public CheckingAccount(float saldo,Cliente intestatario,int numeroConto)
	{
		super(saldo,intestatario, numeroConto);
		transactionCount=0;
	}
	public CheckingAccount(Cliente intestatario,int numeroConto)
	{
		super(intestatario, numeroConto);
		transactionCount=0;
	}
	public int getTransactionCount()
	{
		return transactionCount;
	}
	public void versamento(float d)
	{
		transactionCount++;
		super.versamento(d);
	}
	public boolean prelievo(float d) 
	{
		transactionCount++;
		return super.prelievo(d);
	}
	public void deductFees()
	{
		if (transactionCount > FREE_TRANSACTIONS)
			super.prelievo(TRANSACTION_FEE*(transactionCount-FREE_TRANSACTIONS));
	}
}