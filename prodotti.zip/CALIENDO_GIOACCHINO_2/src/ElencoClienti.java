import java.util.ArrayList;

public class ElencoClienti {
	private ArrayList<Cliente> clienti;
	//costruttori
	public ElencoClienti()
	{
		clienti=new ArrayList<Cliente>();
	}
	public ElencoClienti(Cliente cliente)
	{
		clienti=new ArrayList<Cliente>();
		clienti.add(cliente.clone());
	}
	public void addCliente(Cliente cliente)
	{
		for(Cliente i : clienti)
			if(i.getNome().equals(cliente.getNome()))
			{
				clienti.remove(i);
				clienti.add(cliente.clone());
				return;
			}
		clienti.add(cliente.clone());
	}
	public Cliente removeCliente(Cliente cliente)
	{
		if(!clienti.contains(cliente))
			return null;
		return clienti.remove(clienti.indexOf(cliente)).clone();
	}
	public String getElencoClienti()
	{
		return clienti.toString();
	}
}
