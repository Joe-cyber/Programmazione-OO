
public class MainClass {
	public static void main(String[] args)
	{
		Point p=new Point(5,5);
		Rectangle rect=new Rectangle(p,100,300);
		stampaRettangolo(rect);
		rect.traslate(50, 50);
		stampaRettangolo(rect);		
	}
	static void stampaRettangolo(Rectangle r)
	{
		Point temp=r.getVertex();
		int height=r.getHeigth(), width=r.getWidth();
		System.out.println("Rettangolo in vertice ("+temp.getX()+","+temp.getY()+"), altezza: "+height+" larghezza: "+width);
	}
}
