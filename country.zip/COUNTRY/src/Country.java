
public class Country implements Comparable<Country>{
	private String nome;
	private double superficie;
	public Country(String nome,double superficie)
	{
		this.nome=nome;
		this.superficie=superficie;
	}
	public String getNome()
	{
		return nome;
	}
	public double getSuperficie()
	{
		return superficie;
	}
	public void setName(String nome)
	{
		this.nome=nome;
	}
	public void setSuperficie(double superficie)
	{
		this.superficie=superficie;
	}
	public String toString()
	{
		return getClass().getName()+"[nome="+nome+", superficie="+superficie+"]";
	}
	public int compareTo(Country o) 
	{
		Double s1=superficie,s2=o.superficie;
		return s1.compareTo(s2);
	}
}
