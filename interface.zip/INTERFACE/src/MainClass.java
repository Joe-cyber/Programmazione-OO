
public class MainClass {
	public static void main(String[] args)
	{
		DataSet ds=new DataSet();
		VotoEsame e1=new VotoEsame(100.0,"A+");
		VotoEsame e2=new VotoEsame(50.0,"C");
		VotoEsame e3=new VotoEsame(75.0,"B+");

		ds.addMeasurable(e1);
		ds.addMeasurable(e2);
		ds.addMeasurable(e3);
		System.out.println("Ci sono "+ds.getCount()+" elementi");
		System.out.println("La somma � "+ds.getSum());
		System.out.println("La media � "+ds.getSum()/ds.getCount());
		System.out.println("Il massimo � "+ds.getMax());
		System.out.println("Ci sono "+ds.getMin());
	}
}
