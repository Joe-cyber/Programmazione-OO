
public class VotoEsame implements Measurable,Cloneable{
	private double punteggio;
	private String voto;
	public VotoEsame(double punteggio,String voto)
	{
		this.punteggio=punteggio;
		this.voto=voto;
	}
	public double getPunteggio()
	{
		return punteggio;
	}
	public String getVoto()
	{
		return voto;
	}
	public void setPunteggio(double punteggio)
	{
		this.punteggio=punteggio;
	}
	public void setVoto(String voto)
	{
		this.voto=voto;
	}
	public double getMeasure()
	{
		return punteggio;
	}
	public String toString()
	{
		return getClass().getName()+"[punteggio="+punteggio+", voto="+voto+"]";
	}
	public VotoEsame clone()
	{
		try
		{
			return (VotoEsame)super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
