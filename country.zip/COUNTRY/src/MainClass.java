
public class MainClass {
	public static void main(String[] args)
	{
		Country italia=new Country("Italia",10000000);
		Country ungheria=new Country("Ungheria",100000.0);
		if(italia.compareTo(ungheria)<0)
			System.out.println(italia.getNome()+" � piu' piccola dell'"+ungheria.getNome());
		if(italia.compareTo(ungheria)==0)
			System.out.println(italia.getNome()+" � uguale all'"+ungheria.getNome());
		if(italia.compareTo(ungheria)>0)
			System.out.println(italia.getNome()+" � piu' grande dell'"+ungheria.getNome());
	}
}
