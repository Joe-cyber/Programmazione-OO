import java.util.ArrayList;

public class Centri {
	private ArrayList<CentroUrbano> centers;
	public Centri()
	{
		centers=new ArrayList<CentroUrbano>();
	}
	public Centri(CentroUrbano centro)
	{
		centers=new ArrayList<CentroUrbano>();
		centers.add(centro.clone());
	}
	public ArrayList<CentroUrbano> foundCity(String nome)
	{
		ArrayList<CentroUrbano> citta=new ArrayList<CentroUrbano>();
		for(CentroUrbano i : centers)
			if(i.getNazione().getNome().equals(nome))
				citta.add(i.clone());
		return citta;
	}
	public void addUrbanCenter(CentroUrbano x)
	{
		for(CentroUrbano y : centers)
			if(y.getNazione().equals(x.getNazione())&&y.getNome().equals(x.getNome()))
			{
				centers.remove(y);
				centers.add(x.clone());
				return;
			}
		centers.add(x.clone());
	}
	public CentroUrbano removeUrbanCenter(String nome)
	{
		for(CentroUrbano i : centers)
			if(i.getNome().equals(nome))
			{
				centers.remove(i);
				return i.clone();
			}
		return null;
	}
	
}