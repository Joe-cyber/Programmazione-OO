
public class Cliente implements Cloneable{
	private String nome;
	private String indirizzo;
	private String numeroTelefono;
	public Cliente(String nome,String indirizzo)
	{
		this.nome=nome;
		this.indirizzo=indirizzo;
		numeroTelefono="";
	}
	public Cliente(String nome,String indirizzo,String numeroTelefono)
	{
		this.nome=nome;
		this.indirizzo=indirizzo;
		this.numeroTelefono=numeroTelefono;
	}
	//modificatori
	public void setNome(String nome)
	{
		this.nome=nome;
	}
	public void setIndirizzo(String indirizzo)
	{
		this.indirizzo=indirizzo;
	}
	public void setNumeroTelefono(String numeroTelefono)
	{
		this.numeroTelefono=numeroTelefono;
	}
	//accesso
	public String getNome()
	{
		return nome;
	}
	public String getIndirizzo()
	{
		return indirizzo;
	}
	public String getNumeroTelefono()
	{
		return numeroTelefono;
	}
	public String toString()
	{
		return getClass().getName()+"[nome="+nome+", indirizzo="+indirizzo+", numeroTelefono="+numeroTelefono+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass())
			return false;
		Cliente temp=(Cliente) anObject;
		return temp.indirizzo.equals(indirizzo)&&temp.nome.equals(nome)&&temp.numeroTelefono.equals(numeroTelefono);
	}
	public Cliente clone()
	{
		try
		{
			return (Cliente) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
