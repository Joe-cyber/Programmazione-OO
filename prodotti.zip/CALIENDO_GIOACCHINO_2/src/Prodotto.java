
public class Prodotto implements Cloneable{
	private long codice;
	private String descrizione;
	public Prodotto(long codice, String descrizione)
	{
		this.codice=codice;
		this.descrizione=descrizione;
	}
	//modificatori
	public void setCodice(long codice)
	{
		this.codice=codice;
	}
	public void setDescrizione(String descrizione)
	{
		this.descrizione=descrizione;
	}
	//accesso
	public long getCodice()
	{
		return codice;
	}
	public String getDescrizione()
	{
		return descrizione;
	}
	public String toString()
	{
		return getClass().getName()+"[codice"+codice+", descrizione="+descrizione+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass())
			return false;
		Prodotto temp=(Prodotto) anObject;
		return temp.codice==codice&&temp.descrizione.equals(descrizione);
	}
	public Prodotto clone()
	{
		try
		{
			return (Prodotto) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
