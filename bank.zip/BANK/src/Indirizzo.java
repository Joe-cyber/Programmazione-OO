
public final class Indirizzo implements Cloneable
{
	private String cap;
	private String via;
	private String numeroCivico;
	private String citta;
	public Indirizzo(String cap,String via,String numeroCivico,String citta)
	{
		this.cap=cap;
		this.via=via;
		this.citta=citta;
		this.numeroCivico=numeroCivico;
	}
	public String getVia()
	{
		return via;
	}
	public String getCap()
	{
		return cap;
	}
	public String getNumeroCivico()
	{
		return numeroCivico;
	}
	public String getCitta()
	{
		return citta;
	}
	public String toString()
	{
		return getClass().getName()+" [citt�="+citta+", via="+via+", numeroCivico="+numeroCivico+", cap="+cap+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass()) return false;
		Indirizzo temp=(Indirizzo) anObject;
		return (cap.equals(temp.cap))&&(via.equals(temp.via))&&(citta.equals(temp.citta))&&(numeroCivico.equals(temp.numeroCivico));
	}
	public Indirizzo clone()
	{
		try
		{
			return (Indirizzo) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
