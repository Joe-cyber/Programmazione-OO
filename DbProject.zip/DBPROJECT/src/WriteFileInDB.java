import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class WriteFileInDB <E extends Serializable>{
	private String fileName;
	private int written;
	private File file;
	private ObjectInputStream fIn;
	//constructors
	public WriteFileInDB(E item) 
	{
		written=0;
		fileName=item.getClass().getName()+".dat";
		openFile();
	}
	//metode who load all tuples from file into the DB
	public void loadTableDB()
	{
		E item;
		try
		{
			try 
			{
				item=(E)fIn.readObject();
			}
			catch(ClassCastException a)
			{
				item=null;
				a.getStackTrace();
			}
			//da modificare
			System.out.println(item);
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		written++;
	}
	public void openFile()
	{
		try 
		{
			file=new File(fileName);
			fIn=new ObjectInputStream(new FileInputStream(file));
		} 
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	public void closeFile()
	{
		try 
		{
			fIn.close();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
