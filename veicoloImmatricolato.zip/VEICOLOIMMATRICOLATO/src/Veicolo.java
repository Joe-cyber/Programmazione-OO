public class Veicolo {
	String model;
	String id;
	public Veicolo(String model,String id)
	{
		this.model=model;
		if(noCharactersInString(id))
			this.id=id;
		else
			System.err.println("Codice non valido");
	}
	private boolean noCharactersInString(String s)
	{
		char c='A';
		while((c<='Z')&&(!s.contains(Character.toString(c))))
			c++;
		if(c<='Z')
			return false;
		return true;
	}
	public String getModel()
	{
		return model;
	}
	public String getId()
	{
		return id;
	}
	public void changeModel(String newModel)
	{
		model=newModel;
	}
	public void changeId(String newId)
	{
		id=newId;
	}
}
