
public final class Tag implements Cloneable {
	private double prezzo;
	private String luogoOrigine;
	public Tag(double prezzo,String luogoOrigine)
	{
		this.prezzo=prezzo;
		this.luogoOrigine=luogoOrigine;
	}
	public double getPrezzo()
	{
		return prezzo;
	}
	public String getLuogoOrigine()
	{
		return luogoOrigine;
	}
	public String toString()
	{
		return getClass().getName()+" [prezzo="+prezzo+", luogoOrigine="+luogoOrigine+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null || getClass()!=anObject.getClass())
			return false;
		Tag temp=(Tag) anObject;
		Double prezzo1=temp.prezzo,prezzo2=prezzo;
		return prezzo1.equals(prezzo2)&&temp.luogoOrigine.equals(luogoOrigine);
	}
	public Tag clone()
	{
		try
		{
			return (Tag) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
