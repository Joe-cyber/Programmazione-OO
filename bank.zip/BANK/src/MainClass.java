
public class MainClass {
	public static void main(String args[])
	{
		Indirizzo ind=new Indirizzo("84014","Via dentice","61","Nocera Inferiore");
		Cliente c=new Cliente("Gioacchino Caliendo",ind,"22/2/2000");
		BankAccount a=new BankAccount(100,c,0);
		System.out.println(a);
		BankAccount clone=a.clone();
		System.out.println(clone);
		if(clone.equals(a))
			System.out.println("Funziona");
		else
			System.out.println("Non funziona");
		c.setBirthDate("06/06/1999");
		System.out.println(a);
		System.out.println(clone);
		Cliente c2=new Cliente("Gioacchino Caliente",ind,"22/2/2000");
		a.setIntestatario(c2);
		System.out.println(a);
		System.out.println(clone);
	}
}
