import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class WriteFileInDB <E extends InseribleInDb>{
	private String fileName;
	private int written;
	private ObjectInputStream fIn;
	//constructors
	public WriteFileInDB(E item) 
	{
		written=0;
		fileName=item.getClass().getName()+".dat";
		openFile();
	}
	//metode who load all tuples from file into the DB
	public void loadTableDB()
	{
		E item;
		String s="";
		try
		{
			try 
			{
				item=(E)fIn.readObject();
				s=item.insertCommandSQL();
			}
			catch(ClassCastException a)
			{
				item=null;
				a.getStackTrace();
			}
			//da modificare
			System.out.println(s);
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		written++;
	}
	public void openFile()
	{
		try 
		{
			fIn=new ObjectInputStream(new FileInputStream(new File(fileName)));
		} 
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	public void closeFile()
	{
		try 
		{
			fIn.close();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
