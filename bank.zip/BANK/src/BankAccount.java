public class BankAccount implements Cloneable 
{
	protected float saldo;
	private Cliente intestatario;
	private int numeroConto;
	public BankAccount(float saldo,Cliente intestatario,int numeroConto)
	{
		this.saldo=saldo;
		this.intestatario=intestatario.clone();
		this.numeroConto=numeroConto;
	}
	public BankAccount(Cliente intestatario,int numeroConto)
	{
		this.saldo=0.0f;
		this.intestatario=intestatario.clone();
		this.numeroConto=numeroConto;
	}
	public float getSaldo()
	{
		return saldo;
	}
	public Cliente getIntestatario()
	{
		return intestatario.clone();
	}
	public void setIntestatario(Cliente intestatario)
	{
		this.intestatario=intestatario.clone();
	}
	public int getNumConto()
	{
		return numeroConto;
	}
	public void versamento(float denaroVersato)
	{
		saldo+=denaroVersato;
	}
	public boolean prelievo(float denaroPrelevato)
	{
		if(saldo<denaroPrelevato)
			return false;
		saldo-=denaroPrelevato;
		return true;
	}
	public String toString()
	{
		return getClass().getName()+"[saldo="+saldo+",intestatario="+intestatario.toString()+",numeroConto="+numeroConto+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null||getClass()!=anObject.getClass())
			return false;
		BankAccount temp=(BankAccount) anObject;
		return temp.saldo==saldo&&temp.numeroConto==numeroConto&&temp.intestatario.equals(intestatario);
	}
	public BankAccount clone()
	{
		try
		{
			return (BankAccount) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}