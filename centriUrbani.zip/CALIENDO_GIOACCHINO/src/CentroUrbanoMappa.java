
public class CentroUrbanoMappa extends CentroUrbano{
	private PuntoMappa punto;
	//costruttore
	public CentroUrbanoMappa(PuntoMappa punto,String nome,Nazione nazione,long numeroAbitanti,double temperatura)
	{
		super(nome, nazione, numeroAbitanti, temperatura);
		this.punto=punto;
	}
	//modificatori
	public void setPuntoMappa(PuntoMappa punto)
	{
		this.punto=punto;
	}
	//accesso
	public PuntoMappa getPuntoMappa()
	{
		return punto;
	}
	public String toString()
	{
		return getClass().getName()+" "+super.toString()+" [punto="+punto+"]";
	}
	public boolean equals(Object anObject)
	{
		if(super.equals(anObject))
		{
			CentroUrbanoMappa temp=(CentroUrbanoMappa) anObject;
			return punto.equals(temp.punto);
		}
		return false;
	}
	public CentroUrbanoMappa clone()
	{
		CentroUrbanoMappa cloned=(CentroUrbanoMappa)super.clone();
		if(cloned==null)
			return null;
		cloned.punto=punto;
		return cloned;
	}
}
