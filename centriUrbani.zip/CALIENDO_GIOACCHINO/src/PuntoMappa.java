
public final class PuntoMappa implements Cloneable{
	private double latitudine;
	private double longitudine;
	//costruttori
	public PuntoMappa(double latitudine, double longitudine)
	{
		this.latitudine=latitudine;
		this.longitudine=longitudine;
	}
	//metodi accesso
	public double getLatitudine()
	{
		return latitudine;
	}
	public double getLongitudine()
	{
		return longitudine;
	}
	public String toString()
	{
		return getClass().getName()+"[latitudine="+latitudine+", Longitudine="+longitudine+"]";
	}
	public boolean equals(Object anObject)
	{
		if((anObject==null) || getClass()!=anObject.getClass())
			return false;
		PuntoMappa temp=(PuntoMappa) anObject;
		Double lat1=temp.latitudine,long1=temp.longitudine,lat2=latitudine,long2=longitudine;
		return lat1.equals(lat2)&&long1.equals(long2);
	}
	public PuntoMappa clone()
	{
		try
		{
			return (PuntoMappa) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
