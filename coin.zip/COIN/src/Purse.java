import java.util.ArrayList;
public class Purse {
	private ArrayList <Coin> coins;
	public Purse()
	{
		coins=new ArrayList<Coin>();
	}
	public float getTotal()
	{
		float total=0.0f;
		Coin aCoin;
		for(int i=0;i<coins.size();i++)
		{
			aCoin=coins.get(i);
			total+=aCoin.getValore();
		}
		return total;
	}
	public void addCoin(Coin moneta)
	{
		coins.add(moneta);
	}
	public int conteggio()
	{
		return coins.size();
	}
	public Coin getMin()
	{
		Coin min=coins.get(0),temp;
		for(int i=1;i<coins.size();i++)
		{
			temp=coins.get(i);
			if(min.getValore()>temp.getValore())
				min=temp;
		}
		return min;
	}
	public Coin getMax()
	{
		Coin max=coins.get(0),temp;
		for(int i=1;i<coins.size();i++)
		{
			temp=coins.get(i);
			if(max.getValore()<temp.getValore())
				max=temp;
		}
		return max;
	}
	public void removeCoin(Coin aCoin)
	{
		int index=coins.indexOf(aCoin);
		if(index>-1)
			coins.remove(index);
	}
	public int find(Coin aCoin)
	{
		return coins.indexOf(aCoin);
	}
}

