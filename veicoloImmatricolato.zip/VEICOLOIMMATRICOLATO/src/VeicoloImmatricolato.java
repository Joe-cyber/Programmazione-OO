public class VeicoloImmatricolato extends Veicolo
{
	Targa t;
	Intestatario p;
	public VeicoloImmatricolato(String model, String id,Targa t,Intestatario p) {
		super(model, id);
		this.t=t;
		this.p=p;
	}
	public Targa getTarga()
	{
		return t;
	}
	public Intestatario getIntestatario()
	{
		return p;
	}
}
