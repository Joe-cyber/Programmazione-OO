
public class Intestatario {
	String name;
	String address;
	public Intestatario(String name,String address)
	{
		this.name=name;
		this.address=address;
	}
	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public void changeName(String newName)
	{
		name=newName;
	}
	public void changeAddress(String newAddress)
	{
		address=newAddress;
	}
}
