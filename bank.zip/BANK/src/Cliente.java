
public class Cliente implements Cloneable
{
	public String name;
	public Indirizzo address;
	public String birthDate;
	public Cliente(String name,Indirizzo address,String birthDate)
	{
		this.name=name;
		this.address=address;
		this.birthDate=birthDate;
	}
	public String getName()
	{
		return name;
	}
	public Indirizzo getAddress()
	{
		return address;
	}
	public String getBirthDate()
	{
		return birthDate;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public void setAddress(Indirizzo address)
	{
		this.address=address;
	}
	public void setBirthDate(String birthDate)
	{
		this.birthDate=birthDate;
	}
	public String toString()
	{
		return getClass().getName()+" ["+address.toString()+", name="+name+", "+birthDate.toString()+"]";
	}
	public boolean equals(Object anObject)
	{
		if(anObject==null||getClass()!=anObject.getClass()) return false;
		Cliente cliente=(Cliente)anObject;
		return (name.equals(cliente.name))&&(address.equals(cliente.address))&&(birthDate.equals(cliente.birthDate));
	}
	public Cliente clone()
	{
		try
		{
			return (Cliente) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			return null;
		}
	}
}
