
public class Rectangle
{
	private Point vertex;
	private int height;
	private int width;
	public Rectangle(int height,int width)
	{
		vertex=new Point();
		this.height=height;
		this.width=width;
	}
	public Rectangle(Point vertex,int height,int width)
	{
		this.vertex=vertex;
		this.height=height;
		this.width=width;
	}
	public void traslate(int x,int y)
	{
		vertex.changePoint(vertex.getX()+x, vertex.getY()+y);
	}
	public Point getVertex()
	{
		return vertex;
	}
	public int getWidth()
	{
		return width;
	}
	public int getHeigth()
	{
		return height;
	}
}
