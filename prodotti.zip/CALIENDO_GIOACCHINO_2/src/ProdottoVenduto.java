

public class ProdottoVenduto extends Prodotto{
	private long numeroConfezioni;
	private Cliente cliente;
	public ProdottoVenduto(long codice,String descrizione,long numeroConfezioni,Cliente cliente)
	{
		super(codice,descrizione);
		this.cliente=cliente.clone();
		this.numeroConfezioni=numeroConfezioni;
	}
	//modificatore
	public void setNumeroConfezioni(long numeroConfezioni)
	{
		this.numeroConfezioni=numeroConfezioni;
	}
	public void setCliente(Cliente cliente)
	{
		this.cliente=cliente.clone();
	}
	//accesso
	public Cliente getCliente()
	{
		return cliente;
	}
	public long getNumeroConfezioni()
	{
		return numeroConfezioni;
	}
	public String toString()
	{
		return getClass().getName()+" "+super.toString()+" [numeroConfezioni="+numeroConfezioni+", cliente="+cliente+"]";
	}
	public boolean equals(Object anObject)
	{
		if(!super.equals(anObject))
			return false;
		ProdottoVenduto temp=(ProdottoVenduto) anObject;
		return temp.cliente.equals(cliente)&&temp.numeroConfezioni==numeroConfezioni;
	}
	public ProdottoVenduto clone()
	{
		ProdottoVenduto cloned=(ProdottoVenduto) super.clone();
		if(cloned==null)
			return null;
		cloned.cliente=cliente;
		cloned.numeroConfezioni=numeroConfezioni;
		return cloned;
	}
}
