public class MainClass 
{
	public static void main(String[] args) 
	{
		Targa t=new Targa("ci","000","oo"),t2;
		Intestatario p=new Intestatario("Gioacchino Caliendo","Via Filippo Dentice d'Accadia, 61"),p2;
		VeicoloImmatricolato v=new VeicoloImmatricolato("Lancia Y","11101",t,p);
		String m=v.getModel(),id=v.getId();
		t2=v.getTarga();
		p2=v.getIntestatario();
		System.out.println("Veicolo: "+m+" id: "+id);
		System.out.println("Targa: "+t2.getC1()+t2.getC2()+t2.getC3());
		System.out.println("Proprietario: "+p2.getName()+" Indirizzo: "+p2.getAddress());
	}
}