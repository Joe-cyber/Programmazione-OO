
public interface InseribleInDb {
	String insertCommandSQL();
}
