import javax.swing.JFrame;
//import java.awt.Graphics;
public class mainClass{
	public static void main(String[] args) {
		JFrame window=new JFrame();
		window.setSize(640, 480);
		window.setTitle("Visual rectangle");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
		drawingComponent dc=new drawingComponent();
		window.add(dc);
	}
}