//import java.util.ArrayList;

public class MainClass {
	public static void main(String[] args)
	{
		Nazione italia=new Nazione("Italia",1000000),ungheria=new Nazione("Ungheria",500000);
		CentroUrbano nocera=new CentroUrbano("Nocera Inferiore",italia,16000,22.5);
		CentroUrbano roma=new CentroUrbano("Roma",italia,160000,17.5);
		CentroUrbano budapest=new CentroUrbano("Budapest",ungheria,100000,12.5);

		Centri citta=new Centri(nocera);
		citta.addUrbanCenter(roma);
		citta.addUrbanCenter(budapest);
		System.out.println("Citta italiane: ");
		System.out.println(citta.foundCity("Italia"));
		System.out.println("Citta ungheresi: ");
		System.out.println(citta.foundCity("Ungheria"));
		
		CentroUrbano nocera2=new CentroUrbano("Nocera Inferiore",italia,14000,20);
		citta.addUrbanCenter(nocera2);
		System.out.println("Citta italiane aggiornato: ");
		System.out.println(citta.foundCity("Italia"));
		
		CentroUrbano temp=citta.removeUrbanCenter("Nocera Inferiore");
		System.out.println("Citta italiane ancora aggiornato: ");
		System.out.println(citta.foundCity("Italia"));
		System.out.println("Citt� cancellata "+temp);
		temp=citta.removeUrbanCenter("Budapest");
		System.out.println("Citta ungheresi aggiornato: ");
		System.out.println(citta.foundCity("Ungheria"));
		System.out.println("Citt� cancellata "+temp);

		System.out.println("Cancello una citt� non presente: "+citta.removeUrbanCenter("Torino"));
	}
}
